// popup.js
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('connect_to_server_form');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    console.log('testing');
  });
});
